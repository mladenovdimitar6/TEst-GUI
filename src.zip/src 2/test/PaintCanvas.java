package test;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

public class PaintCanvas extends Canvas {

	private static int DOT = 10;

	private  int width;
	private  int height;

	private Color color = Color.red;
	private List<Point> points = new ArrayList<>();

	PaintCanvas(int canvasWidth, int canvasHeight) {
		width = canvasWidth;
		height = canvasHeight;
		setBackground(Color.WHITE);
	}

	public Dimension getPreferredSize() {
		return new Dimension(width, height);//razmeri
	}

	public void paint(Graphics graphics) {
		Graphics2D g2 = (Graphics2D) graphics;
		g2.setColor(Color.WHITE);
		g2.fillRect(0, 0, width, height);
		g2.setColor(color);
		for (Point point : points) {
			g2.fillOval(point.x - DOT / 2, point.y - DOT / 2, DOT, DOT);
		}
		if (points.size() == 3) {
			g2.drawLine(points.get(0).x, points.get(0).y, points.get(1).x, points.get(1).y);
			g2.drawLine(points.get(1).x, points.get(1).y, points.get(2).x, points.get(2).y);
			g2.drawLine(points.get(2).x, points.get(2).y, points.get(0).x, points.get(0).y);

			g2.drawLine(points.get(0).x, points.get(0).y, (points.get(1).x + points.get(2).x) / 2,
					(points.get(1).y + points.get(2).y) / 2);
			g2.drawLine(points.get(1).x, points.get(1).y, (points.get(2).x + points.get(0).x) / 2,
					(points.get(2).y + points.get(0).y) / 2);
			g2.drawLine(points.get(2).x, points.get(2).y, (points.get(0).x + points.get(1).x) / 2,
					(points.get(0).y + points.get(1).y) / 2);
		}
	}

	public void setColor(Color color) {
		this.color = color;
	}

	public void addPoint(Point point) {
		points.add(point);
		if (points.size() > 3) {
			points.remove(0);
		}
		repaint();
	}
}
