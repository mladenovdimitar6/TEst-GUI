package test;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

public class Paint extends JPanel implements ActionListener, MouseListener {
  private final int width;
  private final int height;
  private final JButton black;
  private final JButton red;
  private final JButton blue;
  private final JButton green;
  private final JButton white;
  private final PaintCanvas canvas;

  public Paint() {
    super(new GridLayout(1, 0));
    width = 1000;
    height = 800;

    red = createButton("Red");
    black = createButton("Black");
    blue = createButton("Blue");
    green = createButton("Green");
    white = createButton("White");

    JPanel c = new JPanel(new BorderLayout());
    JPanel m = new JPanel(new FlowLayout());
    m.add(black);
    m.add(red);
    m.add(blue);
    m.add(green);
    m.add(white);
    c.add(m, BorderLayout.NORTH);
    canvas = new PaintCanvas(width, height);
    canvas.addMouseListener(this);
    c.add(canvas, BorderLayout.CENTER);
    add(c);
  }

  private JButton createButton(String name) {
    JButton btn = new JButton(name);
    btn.addActionListener(this);
    return btn;
  }

  static void createAndShowGUI() {
    JFrame frame = new JFrame("Paint");
    frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    frame.add(new Paint());
    frame.pack();
    frame.setVisible(true);
  }
  
  
  public static void main(String[] args) {
    javax.swing.SwingUtilities.invokeLater( //povikvaposle
        new Runnable() {
          @Override
          public void run() {
            createAndShowGUI();
          }
        });
  }

  public void actionPerformed(ActionEvent e) { //eventobject get source
    if (e.getSource() == black) {
      canvas.setColor(Color.black);
    } else if (e.getSource() == red) {
      canvas.setColor(Color.red);
    } else if (e.getSource() == blue) {
      canvas.setColor(Color.blue);
    } else if (e.getSource() == green) {
      canvas.setColor(Color.green);
    } else if (e.getSource() == white) {
      canvas.setColor(Color.white);
    }
  }
  //

  public void mouseClicked(MouseEvent e) {
    canvas.addPoint(e.getPoint());
  }

  public void mousePressed(MouseEvent e) {
    //
  }

  public void mouseReleased(MouseEvent e) {
    //
  }

  public void mouseEntered(MouseEvent e) {
    //
  }

  public void mouseExited(MouseEvent e) {
    //
  }
}
